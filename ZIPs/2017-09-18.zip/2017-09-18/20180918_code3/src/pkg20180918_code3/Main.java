 /*
 * @author Raul Aguilar
 */
package pkg20180918_code3;


public class Main {
    
    public static void main(String[] args) {
        int number = 7;
        System.out.println("7>>2 => " + (7>>2) );
        System.out.println("7<<3 => " + (7<<3) );
        
    }
    
}
