/**
 * @author Raul Aguilar
 */
package pkg20170918_code2;

public class Main {

    public static void main(String[] args) {
        int x = 89;
        int y = 76;
        
        System.out.println("x | y = " + (x | y) );
        System.out.println("x & y = " + (x & y) );
        System.out.println("x ^ y = " + (x ^ y) );
        System.out.println("-x = " + -x );
    }
    
}
