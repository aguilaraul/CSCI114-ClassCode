/**
 * @author raul aguilar
 */
package csci114_20171129code2;

import java.util.Stack;

public class Csci114_20171129code2 {

    public static void main(String[] args) {
        Stack yourSack = new Stack();
        yourSack.push("Adam");
        yourSack.push("Brenda");
        yourSack.push("Cindy");
        yourSack.push("Dana");
        yourSack.push("Florin");
        System.out.println(yourSack);
        System.out.println(yourSack.pop());
        System.out.println(yourSack.pop());
        
    }
    
}
