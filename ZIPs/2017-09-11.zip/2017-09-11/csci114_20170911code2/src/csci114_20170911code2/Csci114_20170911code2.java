/**
 * @author  Raul Aguilar
 */
package csci114_20170911code2;

public class Csci114_20170911code2 {

    public static void main(String[] args) {
        int value = 23;
        char x ='X';
        double y = 123.45;
        long myLong = 123L;
        String myName ="A";
        String yourName = "Clark Kent";
        boolean areYouThere = true;
        
        int myChar = 65;
        //System.out.println(myChar);
        //System.out.printf("%d => %c", myChar, myChar);
        int i;
        for ( i =0; i < 255; i++) {
            System.out.printf("%d => %c", i,  1);
            System.out.println();
        }
    }
}