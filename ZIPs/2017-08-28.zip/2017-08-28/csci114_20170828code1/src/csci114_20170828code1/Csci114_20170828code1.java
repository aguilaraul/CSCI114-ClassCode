/**
 * @author Raul Aguilar
 */
package csci114_20170828code1;

public class Csci114_20170828code1 {

    public static void main(String[] args) {
        System.out.println("Harvey, Go Away!");
        int category = 5; 
        System.out.println(category);
        System.out.println(23 * 56);
        System.out.println("category" + "\n" + 150);
        
    }
    
}
