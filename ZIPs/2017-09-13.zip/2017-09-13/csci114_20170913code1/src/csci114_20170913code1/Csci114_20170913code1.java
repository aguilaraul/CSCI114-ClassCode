/**
 * @author  Raul Aguilar
 */
package csci114_20170913code1;

public class Csci114_20170913code1 {

    public static void main(String[] args) {
        final double PI=3.14; 
        double xyz = 65.123;
        
        System.out.println("hello");
        xyz = 156;
        
        PI=89.21;
    }
    
}